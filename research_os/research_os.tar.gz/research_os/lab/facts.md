# Measured facts

Seeded from the MMAGAI LeWM runs. The librarian may correct a row only by citing a file.

| id | statement | source |
|---|---|---|
| F1 | Frozen `quentinll/lewm-pusht`. One frame encodes to z of shape (1, 1, 192). | reports CPU probe / sanity script |
| F2 | Ridge z → (cos θ, sin θ): held-out circular MAE 12.08° on scripted 180° frames, 14.58° within 30° of angle 0. Encoder not finetuned. | CPU probe note |
| F3 | Constant Δz per command residual ratio 0.991. One vector per phrase does not explain the turn. | CPU probe note |
| F4 | Official image-goal CEM 45/50 (90%). Action mean [-0.00781, 0.00686], std [0.20847, 0.20675]. CEM 300/30/top 30, horizon 5, action block 5, budget 50, goal 25 steps ahead. | GPU_RUN.md / GPU addendum |
| F5 | Guessed ×5 action scale scored 0/50. Invalid baseline. | GPU_RUN.md |
| F6 | Probe-cost rotate reach 0.10 (+90°) and 0.00 (180°) on the official action transform. | GPU addendum |
| F7 | Oracle rendered goal, same xy, θ+90° or θ+180°: reach 0.00 at budget 50; 180° also 0.00 at budget 100. ‖z_g − z_t‖ was about 15.7 and 18.3. | oracle note |
| F8 | Home CPU has no AVX2. Lance and kornia_rs SIGILL. Push-T runs headless. | SETUP.md |

Conflicts: none recorded yet.
