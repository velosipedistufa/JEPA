# Claim graph

Edges are "depends on", not proof.

```
F1 encoder loads
  └─ F2 angle probe
  └─ F4 official CEM 90%
       ├─ F5 ×5 scale killed (K1)
       ├─ F6 probe-cost rotate ~0
       └─ F7 oracle in-place rotate 0
            └─ K3 do not blame the text encoder
F3 constant Δz fails → K2
F2 angle readable → K4 do not finetune for θ
```

Open, not yet nodes:
- what the 90% protocol is actually sensitive to (goal offset, horizon, action block)
- which non-angle quantities are linear in z
- whether a chain of nearby goal images is followable when a 180° jump is not
