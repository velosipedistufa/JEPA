# Killed mechanisms

Do not reopen these unless a protocol changes the mechanism, not the wording.

| id | mechanism | why |
|---|---|---|
| K1 | Guessed global action scale (×5 or similar) | F5. Official z-score is the only action hook that reached 90%. |
| K2 | Constant Δz lookup per command string | F3. Residual ratio 0.991. |
| K3 | Treating in-place 180° failure as a missing text encoder | F7. A true rendered goal image also scored 0. |
| K4 | Finetuning LeWM because 180° is missing from z | F2. Linear probe already reads 180°. |
| K5 | Text-to-image goal frames | Not measured as a success; rejected because the env frame is the goal, and a generator will not match Push-T calibration. |
